
package aula14atividadebfor;

import java.util.Scanner;

public class Aula14atividadebFOR {

    
    public static void main(String[] args) {
        
        Scanner leitor = new Scanner(System.in);
        
        //Crie uma pequena rotina que exiba "Xª linha loka" 12 vezes, onde X é o valor a linha (a partir de 1)
        
        for (int contador=0; contador<=12; contador++){
            System.out.println(contador+" Linha loka");
        }
    }
    
}
