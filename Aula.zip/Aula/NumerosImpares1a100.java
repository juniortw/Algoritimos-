
package numerosimpares1a100;


public class NumerosImpares1a100 {

    
    public static void main(String[] args) {
        
        int impares = 1;
        
        while (impares <= 100){
            System.out.println(impares);
            impares+=2;
       }
        
    }
    
}
