a = [1]
print (a)

a.append (2)
print (a)

f = int (input ("Novo valor: "))
a.append (f)
print (a)

lista = [2, 4, 8, 3, 9, 6, 1]
print (lista)
lista.sort() #ordena a lista
print (lista) 
lista.reverse() #inverter a lista
print (lista)

gol = [ 3, 5, 8, 2, 0]
gol.reverse ()
print (gol, "Número de elementos = ", len(gol))
