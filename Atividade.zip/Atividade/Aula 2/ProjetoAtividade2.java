﻿
package projetoatividade2;

import java.util.Scanner;

    public class ProjetoAtividade2 {

        public static void main(String[] args) {

            Scanner leitor = new Scanner(System.in);

            System.out.println("Digite seu nome: ");
             String nome = leitor.nextLine();

            System.out.println("Digite sua idade: ");
             String idade = leitor.nextLine();

            System.out.println("Seu nome é:" +nome+ " Sua idade é: "+idade);
            
            
            
    }
    
}
